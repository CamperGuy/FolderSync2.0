# FolderSync2.0
Improved Version of Foldersync
